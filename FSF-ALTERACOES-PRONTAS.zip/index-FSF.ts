import { Router, type IRouter } from "express";
import healthRouter from "./health";
import sharedInboxRouter from "./shared-inbox";
import inboxManagementRouter from "./inbox-management";

const router: IRouter = Router();

router.use(healthRouter);
router.use(sharedInboxRouter);
router.use(inboxManagementRouter);

export default router;
