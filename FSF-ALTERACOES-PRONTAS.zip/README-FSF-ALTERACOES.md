# Fazenda São Francisco — alterações preparadas

Arquivos deste pacote:
- `FsfApp.tsx`: nova interface estável do workspace, com leitura de conversas, rolagem interna, bloqueio colaborativo, envio, status enviada/entregue/lida, acesso aos números, exclusão de membros e saúde do sistema.
- `main-FSF.tsx`: passa a renderizar `FsfApp`.
- `inbox-management.ts`: endpoints adicionais do backend.
- `index-FSF.ts`: registra a nova rota do backend.

Endpoints novos:
- GET `/api/numbers-overview`
- PATCH `/api/conversations/:id/read-v2`
- GET `/api/whatsapp-numbers/:id/access-v2`
- PUT `/api/whatsapp-numbers/:id/access-v2`
- DELETE `/api/users/:id/v2`
- GET `/api/system/status-v2`

A conexão original Frontend → Backend continua sendo configurada por `VITE_API_URL`.
O webhook usado na interface é:
`https://multi-chat-fsf1.onrender.com/api/webhook/uzapi`

A documentação oficial da UZAPI é acessada pelo botão correspondente na interface.
