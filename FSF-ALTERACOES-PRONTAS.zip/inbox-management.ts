import { Router } from 'express';
import { pool } from '@workspace/db';
import { broadcastRealtime } from '../lib/realtime';

const router = Router();
const normalizeRole=(r:any)=>r==='super_admin'||r==='admin'?'super_admin':r==='manager'?'manager':'agent';
const initials=(name:string)=>(name||'FS').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase();

async function currentUser(req:any){
  const token=req.cookies?.fsf_access_token||(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
  if(!token||!process.env.SUPABASE_URL||!process.env.SUPABASE_ANON_KEY)return null;
  const r=await fetch(`${process.env.SUPABASE_URL}/auth/v1/user`,{headers:{apikey:process.env.SUPABASE_ANON_KEY,Authorization:`Bearer ${token}`}});
  if(!r.ok)return null;
  const a:any=await r.json();
  return {id:a.id,name:a.user_metadata?.name||a.user_metadata?.full_name||a.email?.split('@')[0]||'Usuário',email:a.email,role:normalizeRole((await pool.query('select role from public.workspace_users where id=$1',[a.id])).rows[0]?.role),initials:initials(a.user_metadata?.name||a.user_metadata?.full_name||a.email?.split('@')[0]||'Usuário'),online:true};
}
function auth(handler:any){return async(req:any,res:any,next:any)=>{try{const u=await currentUser(req);if(!u)return res.status(401).json({error:'Não autenticado'});req.currentUser=u;return handler(req,res,next)}catch(e){return next(e)}}}

router.get('/numbers-overview',auth(async(_req:any,res:any)=>{
  const q=await pool.query(`select n.id,n.name,n.phone_number,n.phone_number_id,n.provider,n.uzapi_username,n.status,
    coalesce((select sum(c.unread_count) from public.conversations c where c.whatsapp_number_id=n.id),0) unread_count,
    coalesce((select count(*) from public.workspace_user_numbers x where x.whatsapp_number_id=n.id),0) team_count
    from public.whatsapp_numbers n order by n.created_at`);
  res.json(q.rows.map((r:any)=>({id:r.id,name:r.name,phoneNumber:r.phone_number,phoneNumberId:r.phone_number_id,provider:r.provider,uzapiUsername:r.uzapi_username,status:r.status,unreadCount:+r.unread_count,teamCount:+r.team_count})));
}));

router.patch('/conversations/:id/read-v2',auth(async(req:any,res:any)=>{
  const q=await pool.query('update public.conversations set unread_count=0,updated_at=now() where id=$1 returning id,unread_count',[req.params.id]);
  if(!q.rows[0])return res.status(404).json({error:'Conversa não encontrada'});
  broadcastRealtime({type:'conversation.read',conversationId:req.params.id});
  res.json({conversationId:req.params.id,unreadCount:+q.rows[0].unread_count});
}));

router.get('/whatsapp-numbers/:id/access-v2',auth(async(req:any,res:any)=>{
  const n=await pool.query('select id,name from public.whatsapp_numbers where id=$1',[req.params.id]);
  if(!n.rows[0])return res.status(404).json({error:'Número não encontrado'});
  const q=await pool.query(`select u.id,u.name,u.email,u.role,u.online,exists(select 1 from public.workspace_user_numbers x where x.user_id=u.id and x.whatsapp_number_id=$1) has_access from public.workspace_users u order by u.name`,[req.params.id]);
  res.json({number:n.rows[0],users:q.rows.map((r:any)=>({id:r.id,name:r.name,email:r.email,role:normalizeRole(r.role),online:Boolean(r.online),hasAccess:Boolean(r.has_access)}))});
}));

router.put('/whatsapp-numbers/:id/access-v2',auth(async(req:any,res:any)=>{
  const ids=Array.isArray(req.body?.userIds)?req.body.userIds.filter((x:any)=>typeof x==='string'&&x):[];
  const n=await pool.query('select id,name from public.whatsapp_numbers where id=$1',[req.params.id]);
  if(!n.rows[0])return res.status(404).json({error:'Número não encontrado'});
  await pool.query('delete from public.workspace_user_numbers where whatsapp_number_id=$1',[req.params.id]);
  for(const id of ids) await pool.query('insert into public.workspace_user_numbers(user_id,whatsapp_number_id) values($1,$2) on conflict do nothing',[id,req.params.id]);
  broadcastRealtime({type:'number.access.updated',numberId:req.params.id});
  res.json({ok:true,teamCount:ids.length});
}));

router.delete('/users/:id/v2',auth(async(req:any,res:any)=>{
  const id=req.params.id;if(id===req.currentUser.id)return res.status(400).json({error:'Você não pode excluir a própria conta'});
  const q=await pool.query('select id,name,email from public.workspace_users where id=$1',[id]);if(!q.rows[0])return res.status(404).json({error:'Membro não encontrado'});
  await pool.query('update public.conversations set assigned_user_id=null,updated_at=now() where assigned_user_id=$1',[id]);
  await pool.query('delete from public.workspace_user_numbers where user_id=$1',[id]);
  await pool.query('delete from public.workspace_users where id=$1',[id]);
  let authWarning=false;
  if(process.env.SUPABASE_URL&&process.env.SUPABASE_SERVICE_ROLE_KEY){
    const r=await fetch(`${process.env.SUPABASE_URL}/auth/v1/admin/users/${encodeURIComponent(id)}`,{method:'DELETE',headers:{apikey:process.env.SUPABASE_SERVICE_ROLE_KEY,Authorization:`Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`}});authWarning=!r.ok;
  }
  broadcastRealtime({type:'user.deleted',userId:id});res.json({ok:true,authWarning,user:q.rows[0]});
}));

router.get('/system/status-v2',auth(async(_req:any,res:any)=>{
  const out:any={api:true,database:false,uzapi:false,webhook:true,realtime:true,checkedAt:new Date().toISOString()};
  try{await pool.query('select 1');out.database=true}catch{}
  try{
    const q=await pool.query('select phone_number_id,uzapi_username,status from public.whatsapp_numbers order by created_at limit 1');const n=q.rows[0];
    const username=n?.uzapi_username||process.env.UZAPI_USERNAME;const token=process.env.UZAPI_ACCESS_TOKEN;const version=process.env.UZAPI_VERSION||'v1';
    if(username&&token&&n?.phone_number_id){const r=await fetch(`https://api.uzapi.com.br/${encodeURIComponent(username)}/${encodeURIComponent(version)}/${encodeURIComponent(n.phone_number_id)}/instance`,{headers:{Authorization:`Bearer ${token}`}});if(r.ok){const d:any=await r.json().catch(()=>({}));const raw=JSON.stringify(d).toLowerCase();out.uzapi=String(n.status||'').toLowerCase()==='connected'||raw.includes('connected')}}
  }catch{}
  out.percent=Math.round(Object.values({api:out.api,database:out.database,uzapi:out.uzapi,webhook:out.webhook,realtime:out.realtime}).filter(Boolean).length*20);res.json(out);
}));

export default router;
